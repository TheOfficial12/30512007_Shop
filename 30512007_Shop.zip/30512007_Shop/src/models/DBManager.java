package models;
import java.sql.Connection; // Import Connection
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement; // Import Statement
import java.util.ArrayList;
import models.Customer;
import models.Heatpump;
import models.Product;
import models.SolarPanel;
import models.Staff;

/**
 * UPDATED: Simplified all methods to use "try-with-resources"
 * and completed the loadProducts() method.
 * @author 30512007
 */
public class DBManager {

    private static final String DB_URL = "jdbc:ucanaccess://Data/ShopDB.accdb";

    public ArrayList<Customer> loadCustomers() {
        ArrayList<Customer> customers = new ArrayList<>();
        
        // This is "try-with-resources". It's much simpler!
        // It automatically declares and closes conn, stmt, and rs.
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Customers")) {

            // Loop through results
            while (rs.next()) {
                // **IMPORTANT:** Check your Access DB column names match these!
                String username = rs.getString("Username");
                String password = rs.getString("Password");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String address1 = rs.getString("AddressLine1");
                String address2 = rs.getString("AddressLine2");
                String town = rs.getString("Town");
                String postcode = rs.getString("Postcode");

                // Create and add customer
                Customer customer = new Customer(username, password, firstName, lastName, address1, address2, town, postcode);
                customers.add(customer);
            }
        } catch (SQLException e) {
            System.err.println("Error loading customers: " + e.getMessage()); // Basic error message
        }
        // No 'finally' block needed to close connections!
        
        return customers;
    }

    public ArrayList<Staff> loadStaff() {
        ArrayList<Staff> staffList = new ArrayList<>();
        
        // Using "try-with-resources" here too
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Staff")) {

            while (rs.next()) {
                // **IMPORTANT:** Check your Access DB column names match these!
                String username = rs.getString("Username");
                String password = rs.getString("Password");
                String firstName = rs.getString("FirstName");
                String lastName = rs.getString("LastName");
                String position = rs.getString("Position");
                double salary = rs.getDouble("Salary");

                // Create and add staff
                Staff staffMember = new Staff(username, password, firstName, lastName, position, salary);
                staffList.add(staffMember);
            }
        } catch (SQLException e) {
            System.err.println("Error loading staff: " + e.getMessage());
        }
        
        return staffList;
    }
    
    // --- UPDATED AND COMPLETED METHOD ---

    /**
     * Loads all products from the database and creates the correct subclass object.
     * @return An ArrayList of Product objects (containing Heatpump and SolarPanel).
     */
public ArrayList<Product> loadProducts() {
        ArrayList<Product> allProducts = new ArrayList<>();
        
        // Using "try-with-resources"
        // This query selects from the "Products" table
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Products")) {

            while (rs.next()) {
                // 1. Get ALL common and specific data
                int productId = rs.getInt("ProductID");
                String productName = rs.getString("ProductName");
                double price = rs.getDouble("Price");
                int stockLevel = rs.getInt("StockLevel");
                
                // --- FIX 1: Changed "Category" to "ProductType" ---
                String category = rs.getString("ProductType"); 

                // Get specific data
                double efficiency = rs.getDouble("EfficiencyRating"); 
                int wattage = rs.getInt("WattageOutput"); 

                // 2. Check the category to decide which object to create
                
                // --- FIX 2: Changed "Heatpump" to "Heat Pump" (with space) ---
                if (category != null && category.equalsIgnoreCase("Heat Pump")) { 
                    // Create Heatpump, passing the efficiency data
                    Heatpump hp = new Heatpump(productId, productName, price, stockLevel, efficiency);
                    allProducts.add(hp);
                } 
                // --- FIX 2: Changed "SolarPanel" to "Solar Panel" (with space) ---
                else if (category != null && category.equalsIgnoreCase("Solar Panel")) {
                    // Create SolarPanel, passing the wattage data
                    SolarPanel sp = new SolarPanel(productId, productName, price, stockLevel, wattage);
                    allProducts.add(sp);
                }
            }

        } catch (SQLException e) {
            System.err.println("Error loading products: " + e.getMessage());
        }
        
        return allProducts;
    }
    
    
    public Customer customerLogin(String username, String password) {
        ArrayList<Customer> customers = loadCustomers(); // Get all customers
        for (Customer c : customers) { // Loop through them
            // Check username AND password match
            if (c.getUsername().equals(username) && c.getPassword().equals(password)) {
                return c; // Found a match, return the customer
            }
        }
        return null; // No match found
    }

    public Staff staffLogin(String username, String password) {
        ArrayList<Staff> staffList = loadStaff(); // Get all staff
        for (Staff s : staffList) { // Loop through them
            // Check username AND password match
            if (s.getUsername().equals(username) && s.getPassword().equals(password)) {
                return s; // Found a match, return the staff member
            }
        }
        return null; // No match found
    }
}

